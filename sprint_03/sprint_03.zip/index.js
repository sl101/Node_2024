// Для удобства работы вы можете комментировать запуски тех тасок, с которыми не работаете на данный момент.

// Task 01
//const task_01 = require('./task_01');
//console.log(task_01());

// Task 02
//const task_02 = require('./task_02');
//console.log(task_02('d_01'));

// Task 03
//const task_03 = require('./task_03');
//console.log(task_03('./d_01/d_03'));

// Task 04
//const task_04 = require('./task_04');
//console.log(task_04('./d_01/d_02/one.txt'));

// Task 05
//const task_05 = require('./task_05');
//console.log(task_05('./d_01/d_02/one.txt'));

// Task 06
//const task_06 = require('./task_06');
//console.log(task_06('./d_01/d_02/info.txt'));

// Task 07
//const task_07 = require('./task_07');
//console.log(task_07('./d_01/d_02/info.txt'));

// Task 08
//const task_08 = require('./task_08');
//console.log(task_08('./d_01/d_02'));

// Task 09
//const task_09 = require('./task_09');
//console.log(task_09('./d_01/d_02'));

// Task 10
//const task_10 = require('./task_10');
//console.log(task_10('./d_01/d_02'));