// внесите между кавычек ваш apikey
module.exports = '2gzB3eOdSGdi82BW';