const t01 = require('./task_01');
const t02 = require('./task_02');
const t03 = require('./task_03');
const t04 = require('./task_04');
const t05 = require('./task_05');
const t06 = require('./task_06');
const t07 = require('./task_07');
const t08 = require('./task_08');
const t09 = require('./task_09');
const t10 = require('./task_10');
const t11 = require('./task_11');
const t12 = require('./task_12');
const t13 = require('./task_13');
const t14 = require('./task_14');
const t15 = require('./task_15');

// Для удобной работы вызов функций закомментирован. Когда работает с определенным таском - снимите комментарий. Если таск не нужен для запуска - закомментируйте.


// Task 01
//(async () => {
//	console.log(await t01());
//})();

// Task 02
//(async () => {
//	console.log(await t02());
//})();


// Task 03
//(async () => {
//	console.log(await t03(6));
//})();

// Task 04
//(async () => {
//	console.log(await t04());
//})();

// Task 05
//(async () => {
//	console.log(await t05('jeramie_roh@hotmail.com'));
//})();

// Task 06
//(async () => {
//	console.log(await t06());
//})();

// Task 07
//(async () => {
//	console.log(await t07('feyan'));
//})();

// Task 08
//(async () => {
//	console.log(await t08(500, 520));
//})();

// Task 09
//(async () => {
//	console.log(await t09());
//})();

// Task 10
//(async () => {
//	console.log(await t10(8));
//})();

// Task 11
//(async () => {
//	console.log(await t11());
//})();

// Task 12
//(async () => {
//	console.log(await t12('Тюр'));
//})();

// Task 13
//(async () => {
//	console.log(await t13());
//})();

// Task 14
//(async () => {
//	console.log(await t14());
//})();

// Task 15
//(async () => {
//	console.log(await t15());
//})();