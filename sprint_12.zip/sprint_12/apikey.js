// внесите между кавычек ваш apikey
module.exports = 'WqaFnMj8lZCniHug';