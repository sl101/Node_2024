const t01 = require('./task_01');
const t02 = require('./task_02');
const t03 = require('./task_03');
const t04 = require('./task_04');
const t05 = require('./task_05');
const t06 = require('./task_06');
const t07 = require('./task_07');
const t08 = require('./task_08');
const t09 = require('./task_09');
const t10 = require('./task_10');
const t11 = require('./task_11');
const t12 = require('./task_12');
const t13 = require('./task_13');
const t14 = require('./task_14');
const t15 = require('./task_15');

// Для удобной работы вызов функций закомментирован. Когда работает с определенным таском - снимите комментарий. Если таск не нужен для запуска - закомментируйте.

// Перед выполнением работы в консоли наберите npm i


// Task 01
//(async () => {
//	console.log(await t01());
//})();

// Task 02
//(async () => {
//	console.log(await t02(4));
//})();


// Task 03
//(async () => {
//	console.log(await t03('joesph.quitz@yahoo.com'));
//})();

// Task 04
//(async () => {
//	console.log(await t04());
//})();

// Task 05
//(async () => {
//	console.log(await t05(500, 600));
//})();

// Task 06
//(async () => {
//	console.log(await t06());
//})();

// Task 07
//(async () => {
//	console.log(await t07());
//})();

// Task 08
//(async () => {
//	console.log(await t08());
//})();

// Task 09
//(async () => {
//	console.log(await t09(4));
//})();

// Task 10
//(async () => {
//	console.log(await t10('human'));
//})();

// Task 11
//(async () => {
//	console.log(await t11());
//})();

// Task 11
//(async () => {
//	console.log(await t11());
//})();

// Task 12
//(async () => {
//	console.log(await t12());
//})();

// Task 13
//(async () => {
//	console.log(await t13(4));
//})();

// Task 14
//(async () => {
//	console.log(await t14(8, 'up'));
//})();

// Task 15
//(async () => {
//	console.log(await t15(8, 1, 1));
//})();