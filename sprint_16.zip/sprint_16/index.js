const task_05 = require('./tasks/task_05');
const task_06 = require('./tasks/task_06');
const task_07 = require('./tasks/task_07');
const task_08 = require('./tasks/task_08');
const task_09 = require('./tasks/task_09');
const task_10 = require('./tasks/task_10');

// Task 05
//(async () => {
//	console.log(await task_05());
//})();


// Task 06
//(async () => {
//	console.log(await task_06());
//})();


// Task 07
//(async () => {
//	console.log(await task_07());
//})();


// Task 08
//(async () => {
//	console.log(await task_08());
//})();


// Task 09
//(async () => {
//	console.log(await task_09());
//})();


// Task 10
//(async () => {
//	console.log(await task_10());
//})();
