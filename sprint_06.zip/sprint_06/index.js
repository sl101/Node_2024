// !!! Внимание - при выполнении кода может возникнуть много вопросов. Спрашивайте в чате курса!!!!
// Для удобства работы можно комментировать вызовы не используемых в данный момент tasks

// Task 01
const task_01 = require('./task_01');

(async function () {
	let res = await task_01();
	console.log(res);
})();


// Task 02
const task_02 = require('./task_02');

(async function () {
	let res = await task_02();
	console.log(res);
})();


// Task 03
const task_03 = require('./task_03.js');

(async function () {
	let res = await task_03();
	console.log(res);
})();


// Task 04
const task_04 = require('./task_04.js');

(async function () {
	let res = await task_04();
	console.log(res); // ожидаю ['Green', 'Yellow', 'Orange']
})();


// Task 05
const task_05 = require('./task_05.js');

(async function () {
	let res = await task_05();
	console.log(res); // ожидаю [ 'Lime', 'Lemon', 'Orange' ]
})();


// Task 06
const task_06 = require('./task_06.js');

(async function () {
	let res = await task_06();
	console.log(res);
})();


// Task 07
const task_07 = require('./task_07.js');

(async function () {
	let res = await task_07();
	console.log(res);
})();


// Task 08
const task_08 = require('./task_08.js');

(async function () {
	let res = await task_08();
	console.log(res);
})();


// Task 09
const task_09 = require('./task_09.js');

(async function () {
	let res = await task_09();
	console.log(res);
})();


// Task 10
const task_10 = require('./task_10.js');

(async function () {
	let res = await task_10();
	console.log(res);
})();