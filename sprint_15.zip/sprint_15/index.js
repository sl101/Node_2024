//const syncMysql = require('sync-mysql');
//const CONFIG = require('./config');

const task_01 = require('./task_01');
const task_02 = require('./task_02');
const task_03 = require('./task_03');
const task_04 = require('./task_04');
const task_05 = require('./task_05');
const task_06 = require('./task_06');
const task_07 = require('./task_07');
const task_08 = require('./task_08');
const task_09 = require('./task_09');
const task_10 = require('./task_10');
const task_11 = require('./task_11');
const task_12 = require('./task_12');
const task_13 = require('./task_13');
const task_14 = require('./task_14');
const task_15 = require('./task_15');

// Task 01
//console.log(task_01('SELECT model FROM cars'));

// Task 02
//console.log(task_02());

// Task 03
//console.log(task_03());

// Task 04
//console.log(task_04());

// Task 05
//console.log(task_05());

// Task 06
//console.log(task_06());

// Task 07
//console.log(task_07());

// Task 08
//console.log(task_08());

// Task 09
//console.log(task_09());

// Task 10
//console.log(task_10());

// Task 11
//console.log(task_11());

// Task 12
//console.log(task_12());

// Task 13
//console.log(task_13());

// Task 14
//console.log(task_14());

// Task 15
//console.log(task_15());